package com.example.myapplication.util;

import java.util.List;

//list获取数据流
public class Data {
    private int count;
    private List<Datastreams>datastreams;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public List<Datastreams> getDatastreams() {
        return datastreams;
    }

    public void setDatastreams(List<Datastreams> datastreams) {
        this.datastreams = datastreams;
    }
}
