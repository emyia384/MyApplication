package com.example.myapplication.util;

import com.example.myapplication.util.Data;

//json转换
public class JsonRootBean {
    int errno;
    Data data;

    public Data getData() {
        return data;
    }
}
