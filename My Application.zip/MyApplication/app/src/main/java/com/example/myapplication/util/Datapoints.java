package com.example.myapplication.util;

//获取云平台数据
public class Datapoints {
    private String at;
    private String value;

    public String getAt() {
        return at;
    }

    public void setAt(String at) {
        this.at = at;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
